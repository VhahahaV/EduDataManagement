import React, { useState } from "react"
import Navbar from "../component/Navbar"
import { Button, Col, Row, Form, Layout, Table, Upload, Card } from "antd"
import "../App.css"
import { Link, useSearchParams } from "react-router-dom"
import img from "../assets/logo.gif"
import { useEffect } from "react"
import { getClasses, getCourseTeachers, getStudentCourseDataByCourseId } from "../service/students"
import { getAnnouncementById, getAnnouncements } from "../service/students"
const { Header, Content, Footer } = Layout

const HomePage = () => {
  const [announcements, setAnnouncements] = useState([])
  const [params] = useSearchParams()
  const [courses, setCourses] = useState([])
  const [students, setStudents] = useState([])
  const teacherId = params.get("teacherId")

  useEffect(() => {
    getClasses((data) => {
      console.log(data.data)
      getCourseTeachers((result) => {
        let coursesId = []
        let courses = []
        let students = []
        console.log(result.data)
        for (let i = 0; i < result.data.length; i++) {
          if (result.data[i].teacher == teacherId) {
            coursesId.push(result.data[i].course)
          }
        }
        for (let j = 0; j < coursesId.length; j++) {
          getStudentCourseDataByCourseId(coursesId[j], (student_data) => {
            //console.log(student_data.data)
            for (let z = 0; z < student_data.data.length; z++) {
              students = [...students, student_data.data[z]]
              setStudents(students)
            }
            //console.log(students)
          })
          for (let k = 0; k < data.data.length; k++) {
            if (data.data[k].id == coursesId[j]) {
              courses.push(data.data[k])
            }
          }
        }
        setCourses(courses)
      })
    })
  }, [])

  const columns = [
    {
      title: <p style={{ fontSize: "17px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>公告标题</p>,
      dataIndex: 'title',
      key: 'title',
      render: (text, record) => <Link to={{
        pathname: "/announcement",
        search: "?id=" + record.id + "&teacherId=" + teacherId
      }}>
        <Button type="link" style={{ fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>{text}</Button>
      </Link>
    },
    {
      title: <p style={{ fontSize: "17px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>公告时间</p>,
      dataIndex: 'time',
      key: 'time',
      render: (text) => <span style={{ fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>{text}</span>
    },
    {
      title: <p style={{ fontSize: "17px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>公告作者</p>,
      dataIndex: 'username',
      key: 'username',
      render: (text) => <span style={{ fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>{text}</span>
    }
  ]

  const columns1 = [
    {
      title: <p style={{ fontSize: "17px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>课程名称</p>,
      dataIndex: 'className',
      key: 'className',
      render: (text, record) => <Link to={{
        pathname: "/classTeacher",
        search: "?id=" + record.id + "&teacherId=" + teacherId
      }}>
        <Button type="link" style={{ fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>{text}</Button>
      </Link>
    },
    {
      title: <p style={{ fontSize: "17px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>课程时间</p>,
      dataIndex: 'classTime',
      key: 'classTime',
      render: (text) => <span style={{ fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>{text}</span>
    },
    {
      title: <p style={{ fontSize: "17px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>授课教师</p>,
      dataIndex: 'teachers',
      key: 'teachers',
      render: (teachers) => {
        const teacherNames = teachers.map(teacher => teacher.name)
        return <span style={{ fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>
          {teacherNames.join(",")}
        </span>
      }
    }
  ]

  const columns2 = [
    {
      title: <p style={{ fontSize: "17px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>学生昵称</p>,
      dataIndex: 'student',
      key: 'student',
      render: (_, record) => <Link to={{
        pathname: "/study",
        search: "?id=" + record.id + "&teacherId=" + teacherId
      }}>
        <Button type="link" style={{ fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>{record.student.name}</Button>
      </Link>
    },
    {
      title: <p style={{ fontSize: "17px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>学生课程</p>,
      dataIndex: 'class',
      key: 'class',
      render: (_, record) => <span style={{ fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>{record.course.className}</span>
    },
    {
      title: <p style={{ fontSize: "17px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>学生进度</p>,
      dataIndex: 'process',
      key: 'process',
      render: (text) => <span style={{ fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>{text}</span>
    }
  ]




  useEffect(() => {
    getAnnouncements((data) => {
      //console.log(result)
      setAnnouncements(data.data)
    })
  }, [])


  return (
    courses && students && announcements ?
      <Layout style={{ minHeight: "100vh" }}>
        <Header className="header">
          <img src={img} className="img"></img>
          <div className="logo" style={{ fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>学不会平台</div>
          <Navbar />
        </Header>

        <Content>
          <Col>
            <Row>
              <Content style={{ margin: "64px 64px", backgroundColor: "#fff", padding: "32px", boxShadow: "0 2px 8px rgba(0, 0, 0, 0.15)", borderRadius: "8px" }}>
                <h1 style={{ fontSize: "25px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>平台公告栏</h1>
                <Table dataSource={announcements} columns={columns} />
              </Content>
            </Row>
            <Row>
              <Col span={12}>
                <Content style={{
                  marginLeft: "64px",
                  boxShadow: " 0 2px 8px rgba(0, 0, 0, 0.15)",
                  border: " 1px solid rgba(0, 0, 0, 0.1)",
                  padding: "16px",
                  borderRadius: "8px"
                }}>
                  <h1 style={{ fontSize: "25px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>我教授的课程</h1>
                  <Table dataSource={courses} columns={columns1} />
                </Content>
              </Col>
              <Col span={12}>
                <Content style={{
                  marginLeft: "16px",
                  marginRight: "64px",
                  boxShadow: " 0 2px 8px rgba(0, 0, 0, 0.15)",
                  border: " 1px solid rgba(0, 0, 0, 0.1)",
                  padding: "16px",
                  borderRadius: "8px"
                }}>
                  <h1 style={{ fontSize: "25px", fontFamily: "'Comic Sans MS', 'Comic Sans', cursive" }}>我的学生</h1>
                  <Table dataSource={students} columns={columns2} />
                </Content>
              </Col>
            </Row>
          </Col>
        </Content>
        <Footer>
        </Footer>
      </Layout>
      :
      null)
}

export default HomePage
